﻿// See https://aka.ms/new-console-template for more information
namespace Lab7_Pablo_Cabrera

{

    class Laboratorio7
 
    {

        static void Main(string[] args) 

        {
            Console.WriteLine("Mi segundo programa");
            string Nombre;
            string Edad;
            string Carrera;
            string Carne;

            Console.WriteLine("Por favor, ingrese su Nombre");
                Nombre = Console.ReadLine();
            Console.WriteLine("Por favor, ingrese su Edad");
                Edad = Console.ReadLine();
            Console.WriteLine("Por favor, ingrese su Carrera");
                Carrera = Console.ReadLine();
            Console.WriteLine("Por favor, ingrese su Carné");
                Carne = Console.ReadLine();

            Console.WriteLine("Soy " + Nombre + ", tengo " + Edad + " años" + " y estudio la carrera de " + Carrera);
            Console.WriteLine("Mi número de carné es: " + Carne);

            Console.ReadKey();

            double Vfd;
            double Vod;
            double ad;
            double td;
            Console.WriteLine("Por favor, ingrese la velocidad inicial");
                Vod = Double.Parse(Console.ReadLine());
            Console.WriteLine("Por favor, ingrese la aceleración");
                ad = Double.Parse(Console.ReadLine());
            Console.WriteLine("Por favor, ingrese el tiempo");
                td = Double.Parse(Console.ReadLine());

                Vfd = Vod + (ad * td) ;

                Console.WriteLine("La velocidad final es: " + Vfd);
        }

    }
 
}