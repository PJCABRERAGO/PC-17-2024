﻿using System;

namespace T2_PJ12345_E1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Calculadora de Movimiento Rectilíneo Uniformemente Variado");
            Console.WriteLine("Ingrese los datos conocidos:");
            Console.WriteLine("1. Velocidad Final (V0)");
            Console.WriteLine("2. Velocidad Inicial  (a)");
            Console.WriteLine("3. Aceleración  (t)");
            Console.WriteLine("4. Tiempo (Vf)");
            Console.WriteLine();

            double v0 = double.NaN;
            double a = double.NaN;
            double t = double.NaN;
            double vf = double.NaN;

            Console.Write("Seleccione el dato a calcular (1-4): ");
            int opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    Console.Write("Ingrese la velocidad inicial. (s): ");
                    v0 = double.Parse(Console.ReadLine());
                    Console.Write("Ingrese la aceleración (m/s^2): ");
                    a = double.Parse(Console.ReadLine());
                    Console.Write("Ingrese el tiempo (s): ");
                    t = double.Parse(Console.ReadLine());
                    vf = v0 + (a * t);
                    Console.WriteLine($"La velocidad final es: {vf} m/s");
                    break;
                case 2:
                    Console.Write("Ingrese la velocidad final. (m/s): ");
                    vf = double.Parse(Console.ReadLine());
                    Console.Write("Ingrese la aceleración. (m/s^2): ");
                    a = double.Parse(Console.ReadLine());
                    Console.Write("Ingrese el tiempo (s): ");
                    t = double.Parse(Console.ReadLine());
                    v0 = vf - (a * t);
                    Console.WriteLine($"La velocidad inicial es: {v0} m/s");
                    break;
                case 3:
                    Console.Write("Ingrese la velocidad inicial. (m/s): ");
                    v0 = double.Parse(Console.ReadLine());
                    Console.Write("Ingrese la velocidad final. (m/s): ");
                    vf = double.Parse(Console.ReadLine());
                    Console.Write("Ingrese el tiempo. (s): ");
                    t = double.Parse(Console.ReadLine());
                    a = (vf- v0)/t ;
                    Console.WriteLine($"La aceleración es: {a} m/s^2");
                    break;
                case 4:
                    Console.Write("Ingrese la velocidad inicial. (m/s): ");
                    v0 = double.Parse(Console.ReadLine());
                    Console.Write("Ingrese la velocidad final. (m/s): ");
                    vf = double.Parse(Console.ReadLine());
                    Console.Write("Ingrese la aceleración. (m/s^2): ");
                    a = double.Parse(Console.ReadLine());
                    t = (vf- v0)/a;
                    Console.WriteLine($"La velocidad final es: {vf} m/s");
                    break;
                default:
                    Console.WriteLine("Opción no válida.");
                    break;
            }
        }
    }
}