﻿using System;

namespace T2_XXXXXX_1422616_E2 // Reemplaza XXXXXX con tus iniciales
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Pablo Cabrera - 1278724"); // Reemplaza con tu nombre y número de carné

            Console.WriteLine("Ingrese una cantidad en quetzales (entre 0 y 999.99):");
            double cantidad = double.Parse(Console.ReadLine());
            
            int billetes100 = (int)(cantidad / 100);
            cantidad %= 100;

            int billetes50 = (int)(cantidad / 50);
            cantidad %= 50;

            int billetes20 = (int)(cantidad / 20);
            cantidad %= 20;

            int billetes10 = (int)(cantidad / 10);
            cantidad %= 10;

            int billetes5 = (int)(cantidad / 5);
            cantidad %= 5;

            int monedas1 = (int)(cantidad / 1);
            cantidad %= 1;

            int monedas25 = (int)(cantidad / 0.25);
            cantidad %= 0.25;

            int monedas1Centavo = (int)(cantidad / 0.01);

            Console.WriteLine($"{billetes100} de Q 100");
            Console.WriteLine($"{billetes50} de Q 50");
            Console.WriteLine($"{billetes20} de Q 20");
            Console.WriteLine($"{billetes10} de Q 10");
            Console.WriteLine($"{billetes5} de Q 5");
            Console.WriteLine($"{monedas1} de Q 1");
            Console.WriteLine($"{monedas25} de 25 centavos");
            Console.WriteLine($"{monedas1Centavo} de 1 centavo");
        }
    }
}